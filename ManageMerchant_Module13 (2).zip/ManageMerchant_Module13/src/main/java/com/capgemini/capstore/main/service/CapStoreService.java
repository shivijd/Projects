package com.capgemini.capstore.main.service;

import java.util.Optional;

import com.capgemini.capstore.main.Merchant;

public interface CapStoreService {
	public Merchant addMerchant(Merchant merchant);
	public Optional<Merchant> removeMerchant(int merchantId);


}
