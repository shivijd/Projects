package com.capgemini.capstore.main.repo;
import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.capstore.main.Merchant;



public interface CapStoreMerchant extends JpaRepository<Merchant, Integer>
{

}
