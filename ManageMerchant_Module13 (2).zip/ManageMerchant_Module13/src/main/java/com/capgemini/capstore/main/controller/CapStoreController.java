package com.capgemini.capstore.main.controller;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.main.Merchant;

import com.capgemini.capstore.main.service.CapStoreService;

@RestController
public class CapStoreController {

	@Autowired 
	CapStoreService capstore;
	
	
	@RequestMapping(method = RequestMethod.POST, value = "/addmerchant")
	public Merchant addMerchant(@Valid @RequestBody Merchant merchant)  {
		return capstore.addMerchant(merchant);
	}
	
	@RequestMapping(method = RequestMethod.DELETE, value = "/deletemerchant/{merchantId}")
	public Optional<Merchant> removeMerchant(@Valid @PathVariable int merchantId) {
		return capstore.removeMerchant(merchantId);
	}
	
}
