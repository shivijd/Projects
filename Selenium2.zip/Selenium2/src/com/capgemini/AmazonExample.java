package com.capgemini;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AmazonExample {
	WebDriver driver;
	public static void main(String[] args) {
		new AmazonExample().amazonDetails();
	}
	public void amazonDetails()
	{
		  System.setProperty("webdriver.chrome.driver","C:\\Users\\SHJADAUN\\Downloads\\chromedriver_win32\\chromedriver.exe");
		   driver=new ChromeDriver();
		   driver.manage().deleteAllCookies();
			driver.manage().window().maximize();
	}

}
