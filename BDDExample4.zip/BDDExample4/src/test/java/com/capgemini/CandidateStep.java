package com.capgemini;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.IsEqual.equalTo;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;



public class CandidateStep {
	private Candidate candy=new Candidate();

	@Given("^that the candidate (.*) having age (\\d+) eligible for voting$")
	public void votingDetails(String name, int age) throws Throwable {
	     candy.setName(name);
	     candy.setAge(age);
		
	}

	@When("^(.*) age is greater than(\\d+)$")
 public void shivi_age_is_greater_than(String name,int age) throws Throwable  {
	   candy.setName(name);
		candy.setAge(age);
	}

	@Then("^(.*) is  eligible for voting$")
	public void shivi_is_eligible_for_voting() throws Throwable  {
		assertThat(candy.getName(), is(candy.getName()));
		//assertThat(candy.getAge(), equalTo(18));
		assertThat(candy.getVoter(candy.getAge()), is(true));
	}
}
