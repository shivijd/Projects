package com.capgemini.page;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.capgemini.base.TestBase;

public class RegistrationPage extends TestBase{
	
	@FindBy(xpath="//*[@id=\"usrID\"]")
	@CacheLookup
	WebElement userid;
	
	@FindBy(xpath="//*[@id=\"pwd\"]")
	@CacheLookup
	WebElement password;
	
	@FindBy(xpath="//*[@id=\"usrname\"]")
	@CacheLookup
	WebElement name;
	
	@FindBy(xpath="//*[@id=\"addr\"]")
	@CacheLookup
	WebElement address;

	@FindBy(xpath="/html/body/form/ul/li[10]/select")
	@CacheLookup
	WebElement select;
	
		
	
	@FindBy(xpath="/html/body/form/ul/li[12]/input")
	@CacheLookup
	WebElement zipcode;
	
	@FindBy(xpath="/html/body/form/ul/li[14]/input")
	@CacheLookup
	WebElement email;
	
	@FindBy(xpath="/html/body/form/ul/li[16]/input")
	@CacheLookup
	WebElement male;
	
	@FindBy(xpath="/html/body/form/ul/li[17]/input")
	@CacheLookup
	WebElement female;
	
	
	@FindBy(xpath="/html/body/form/ul/li[19]/input")
	@CacheLookup
	WebElement english;
	
	@FindBy(xpath="/html/body/form/ul/li[20]/input")
	@CacheLookup
	WebElement nonEnglish;
	
	@FindBy(xpath="//*[@id=\"desc\"]")
	@CacheLookup
	WebElement About;
	
	@FindBy(xpath="/html/body/form/ul/li[23]/input")
	@CacheLookup
	WebElement submit;
	
	public RegistrationPage()
	{
		PageFactory.initElements(driver, this);
	}
	public String getTitle1()
	{
		return driver.getTitle();
	}
	public WebElement getUserid() {
		return userid;
	}
	public void setUserid(String usserid) {
	 userid.sendKeys(usserid);
	}
	public WebElement getPassword() {
		return password;
	}
	public void setPassword(String paassword) {
	 password.sendKeys(paassword);
	}
	public WebElement getName() {
		return name;
	}
	public void setName(String naame) {
		this.name.sendKeys(naame);
	}
	public WebElement getAddress() {
		return address;
	}
	public void setAddress(String aaddress) {
		this.address.sendKeys(aaddress);
	}
	public void setCountry(String country) {
		Select drpCountry = new Select(select);
		drpCountry.selectByVisibleText(country);
		 
	}
	public void setSex(String Sex)
	{
		if(Sex.equals("male"))
			this.male.click();
		if(Sex.equals("female"))
			this.female.click();
	}
	public void setLanguage(String lang)
	{
		if(lang.equals("english"))
			english.click();
		if(lang.equals("nonEnglish"))
			nonEnglish.click();
	}

	public WebElement getZipcode() {
		return zipcode;
	}
	public void setZipcode(String ziipcode) {
		this.zipcode.sendKeys(ziipcode);
	}
	public WebElement getEmail() {
		return email;
	}
	public void setEmail(String mail) {
		 email.sendKeys(mail);
	}
		
	public WebElement getAbout() {
		return About;
	}
	public void setAbout(String abbout) {
		About.sendKeys(abbout);
	}
	public WebElement getSubmit() {
		return submit;
	}
	public void setSubmit() {
		submit.click();
	}
}
