package com.capgemini.pages;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.capgemini.TestBase;

public class LoginPage extends TestBase {
	
	@FindBy(xpath="//*[@id=\"employeeID\"]")
	WebElement id;
	
	@FindBy(xpath="//*[@id=\"name\"]")
	WebElement name;
	
	@FindBy(xpath="//*[@id=\"city\"]")
	WebElement city;
	
	@FindBy(xpath="//*[@id=\"state\"]")
	WebElement state;
	
	@FindBy(xpath="//*[@id=\"employeeDetails\"]/table/tbody/tr[5]/th[1]/input")
	WebElement btn;
	
	public LoginPage()
	{
		PageFactory.initElements(driver, this);
	}
	
	public String getTitle()
	{
		return driver.getTitle();
	}
	
	
	public void pagelogin(String empid,String nam,String cit,String stat)
	{
		id.sendKeys(empid);
		name.sendKeys(nam);
		city.sendKeys(cit);
		state.sendKeys(stat);
		
		btn.click();
	
	}

}
