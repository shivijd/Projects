package com.capgemini.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.capgemini.TestBase;

public class Project extends TestBase{
	@FindBy(xpath="/html/body/form/table/tbody/tr[1]/td/input")
	WebElement input;
	
	@FindBy(name = "jv")
	WebElement jv;
	
	@FindBy(name = "bd")
	WebElement bd;
	
	@FindBy(name = "sl")
	WebElement se;
	
	@FindBy(name = "html")
	WebElement html;
	
	@FindBy(xpath = "/html/body/form/table/tbody/tr[2]/td/input[5]")
	WebElement reg;
	
	public Project() {
		PageFactory.initElements(driver, this);
	}
	public String getTitle1()
	{
		return driver.getTitle();
	}
	public void pageLogin(String inpu,String lang)
	{
		input.sendKeys(inpu);
		if(lang.equals("jv"))
			jv.click();
		if(lang.equals("bd"))
			bd.click();
		if(lang.equals("se"))
			se.click();
		if(lang.equals("html"))
			html.click();
		reg.click();
		
		
	}
}
