package com.capgemini.capstore.main;
public enum Category {
	Electronics, Clothing, FootWear, Grocery, Cosmetics
}
