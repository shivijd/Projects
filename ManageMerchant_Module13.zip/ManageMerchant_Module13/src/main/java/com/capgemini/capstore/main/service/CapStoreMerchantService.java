package com.capgemini.capstore.main.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.capgemini.capstore.main.Merchant;
import com.capgemini.capstore.main.repo.CapStoreMerchant;
@Service
public class CapStoreMerchantService implements CapStoreService{
 @Autowired
 CapStoreMerchant merchant1;
	
	
	@Override
	public Merchant addMerchant(Merchant merchant) {

		merchant1.save(merchant);
		return merchant;
	}

	@Override
	public Optional<Merchant> removeMerchant(int merchantId) {
	   Optional<Merchant> merchant=merchant1.findById(merchantId);
		 merchant1.deleteById(merchantId);
		 return merchant;
	
		
	}


	
}
