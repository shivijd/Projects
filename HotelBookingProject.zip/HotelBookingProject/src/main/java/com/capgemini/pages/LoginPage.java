package com.capgemini.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.capgemini.base.TestBase;

public class LoginPage extends TestBase{
	
	@FindBy(xpath="//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[2]/td[2]/input")
	@CacheLookup
	WebElement name;
	
	@FindBy(xpath="//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[3]/td[2]/input")
	@CacheLookup
	WebElement pswd;
	
	@FindBy(xpath="//*[@id=\"mainCnt\"]/div/div[1]/form/table/tbody/tr[4]/td[2]/input")
	@CacheLookup
	WebElement btn;
	
	public LoginPage()
	{
		PageFactory.initElements(driver, this);
	}
	
	public WebElement getName() {
		return name;
	}
	public void setName(String lname) {
		name.sendKeys(lname);
	}
	public WebElement getPswd() {
		return pswd;
	}
	public void setPswd(String pwd) {
		pswd.sendKeys(pwd);
	}
	public WebElement getBtn() {
		return btn;
	}
	public void setBtn() {
		 btn.click();
	}
	public String getTitle()
	{
		return driver.getTitle();
	}

	
	

}
