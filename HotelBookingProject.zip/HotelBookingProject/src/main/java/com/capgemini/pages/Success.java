package com.capgemini.pages;

import com.capgemini.base.TestBase;

public class Success extends TestBase{
  public String getTit()
  {
	  return driver.getTitle();
  }
}
