package com.capgemini.pages;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.capgemini.base.TestBase;

public class HotelBooking extends TestBase {
	
	
	@FindBy(xpath="//*[@id=\"txtFirstName\"]")
	@CacheLookup
	WebElement fname;
	
	@FindBy(xpath="//*[@id=\"txtLastName\"]")
	@CacheLookup
	WebElement lname;
	

	@FindBy(xpath="//*[@id=\"txtEmail\"]")
	@CacheLookup
	WebElement mail;
	
	@FindBy(xpath="//*[@id=\"txtPhone\"]")
	@CacheLookup
	WebElement phne;
	
	@FindBy(xpath="/html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")
	@CacheLookup
	WebElement add;
	
	
	@FindBy(xpath="/html/body/div/div/form/table/tbody/tr[7]/td[2]/select")
	@CacheLookup
	WebElement city;
	
	@FindBy(xpath="/html/body/div/div/form/table/tbody/tr[8]/td[2]/select")
	@CacheLookup
	WebElement state;
	
	@FindBy(xpath="/html/body/div/div/form/table/tbody/tr[10]/td[2]/select")
	@CacheLookup
	WebElement room;
	

	@FindBy(xpath="//*[@id=\"txtCardholderName\"]")
	@CacheLookup
	WebElement card;
	
	@FindBy(xpath="//*[@id=\"txtDebit\"]")
	@CacheLookup
	WebElement dbt;
	
	@FindBy(xpath="//*[@id=\"txtCvv\"]")
	@CacheLookup
	WebElement cvv;
	
	@FindBy(xpath="//*[@id=\"txtMonth\"]")
	@CacheLookup
	WebElement mon;
	
	@FindBy(xpath="//*[@id=\"txtYear\"]")
	@CacheLookup
	WebElement year;
	
	@FindBy(xpath="//*[@id=\"btnPayment\"]")
	@CacheLookup
	WebElement pay;
	
	public WebElement getFname() {
		return fname;
	}

	public void setFname(String firname) {
		fname.sendKeys(firname);
	}

	public WebElement getLname() {
		return lname;
	}

	public void setLname(String laname) {
		lname.sendKeys(laname);
	}

	public WebElement getMail() {
		return mail;
	}

	public void setMail(String email) {
		 mail.sendKeys(email);
	}

	public WebElement getPhne() {
		return phne;
	}

	public void setPhne(String mob) {
		phne.sendKeys(mob);
	}

	public WebElement getAdd() {
		return add;
	}

	public void setAdd(String add1) {
		 add.sendKeys(add1);
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String sele) {
		Select drpCity = new Select(city);
		drpCity.selectByVisibleText(sele);
		 
	}

	public WebElement getRoom() {
		return room;
	}

	public void setRoom(String room1) {
		Select ro=new Select(room);
		ro.selectByVisibleText(room1);
	}
	


	public WebElement getState() {
		return state;
	}

	public void setState(String state1) {
		Select ro1=new Select(state);
		ro1.selectByVisibleText(state1);
	}

	public WebElement getCard() {
		return card;
	}

	public void setCard(String card1) {
		 card.sendKeys(card1);
	}

	public WebElement getDbt() {
		return dbt;
	}

	public void setDbt(String db) {
	dbt.sendKeys(db);
	}

	public WebElement getCvv() {
		return cvv;
	}

	public void setCvv(String cvv1) {
		 cvv.sendKeys(cvv1);;
	}

	public WebElement getMon() {
		return mon;
	}

	public void setMon(String mon1) {
		 mon.sendKeys(mon1);
	}

	public WebElement getYear() {
		return year;
	}

	public void setYear(String year1) {
	year.sendKeys(year1);
	}

	public WebElement getPay() {
		return pay;
	}

	public void setPay() {
		 pay.click();
	}

	public String getTitle1()
	{
		return driver.getTitle();
	}
	public HotelBooking()
	{
		PageFactory.initElements(driver, this);
	}

}
