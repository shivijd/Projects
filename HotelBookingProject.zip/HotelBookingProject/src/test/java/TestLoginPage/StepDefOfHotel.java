package TestLoginPage;

import static org.testng.Assert.assertEquals;

import com.capgemini.base.TestBase;
import com.capgemini.pages.HotelBooking;
import com.capgemini.pages.LoginPage;
import com.capgemini.pages.Success;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;



public class StepDefOfHotel extends TestBase {
	
	static LoginPage login;
	static HotelBooking book;
	static Success success;
	
	public StepDefOfHotel() {
		super();
		setup();		
	}
	
	
	private void setup() {
		initialization().get("C:\\Users\\SHJADAUN\\Desktop\\pages\\App\\hotelbooking.html");
		login=new LoginPage();
		book= new HotelBooking();
		success=new Success();
			
	}


	@Given("^Hostel Booking page is open$")
	public void hostel_Booking_page_is_open() throws Throwable {
	    System.out.println("Reached given of hiotel");
	    
	}

	@When("^All deatils filled are correct$")
	public void all_deatils_filled_are_correct() throws Throwable {
		book.setFname("Shivi");
		Thread.sleep(1000);
		book.setLname("jadaun");
		Thread.sleep(1000);
		book.setMail("shivijadaun@gmail.com");
		Thread.sleep(1000);
		book.setPhne("9935321397");
		Thread.sleep(1000);
		book.setAdd("fahglgjdf");
		Thread.sleep(1000);
		book.setCity("Pune");
		Thread.sleep(1000);
		book.setState("Maharashtra");
		Thread.sleep(1000);
		book.setRoom("2");
		Thread.sleep(1000);
		book.setCard("shivi");
		Thread.sleep(1000);
		book.setDbt("2314454");
		Thread.sleep(1000);
		book.setCvv("544");	
		Thread.sleep(1000);
		book.setMon("03");
		Thread.sleep(1000);
		book.setYear("2019");
		Thread.sleep(1000);
		book.setPay();
	   
	}

	@Then("^Successfully return the title of success page$")
	public void successfully_return_the_title_of_success_page() throws Throwable {
		assertEquals("Payment Details", success.getTit());
	  
	}



}
