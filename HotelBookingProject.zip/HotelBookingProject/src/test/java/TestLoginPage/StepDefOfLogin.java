package TestLoginPage;

import static org.testng.Assert.assertEquals;

import com.capgemini.base.TestBase;
import com.capgemini.pages.HotelBooking;
import com.capgemini.pages.LoginPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefOfLogin extends TestBase {

	static LoginPage login;
	static HotelBooking booking;

	public StepDefOfLogin() {
		super();
		setup();
	}

	private void setup() {
		initialization().get("C:\\Users\\SHJADAUN\\Desktop\\pages\\App\\login.html");
		login=new LoginPage();
		booking=new HotelBooking();

	}

	@Given("^Login Page is open$")
	public void login_Page_is_open() throws Throwable {

	}

	@When("^Name ans password are correct$")
	public void name_ans_password_are_correct() throws Throwable {
		login.setName("capgemini");
		login.setPswd("capg1234");
		login.setBtn();
		Thread.sleep(8000);

	}

	@Then("^Check the title of next page$")
	public void check_the_title_of_next_page() throws Throwable {
		assertEquals("Hotel Booking", booking.getTitle1());
	}

}
