package mypack;
import org.junit.Ignore;
import org.junit.Test;
public class MainApp {

		
		 @Ignore 
		 @Test
		 public void display()
		 {
		  System.out.println("I am in display");
		  }
		 @Ignore 
		 @Test
		 public void exit()
		 {
		  System.out.println("I am in exit");
		 }
		 @Ignore 
		 @Test
		 public void print()
		 {
		  System.out.println("I am in print");
		 }
		}




