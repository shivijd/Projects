package com.cg.product.Product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.product.Product.bean.Product;
import com.cg.product.Product.repo.IProductRepository;


@Transactional
@Service("service")
public class ProductServiceImpl implements IProductService
{
	@Autowired
	IProductRepository repo;

	public IProductRepository getRepo() {
		return repo;
	}

	public void setRepo(IProductRepository repo) {
		this.repo = repo;
	}

	@Override
	public Product addProduct(Product pro) {
		
		return repo.addProduct(pro);
	}

	@Override
	public Product getById(int ProdId) {
		
		return repo.getById(ProdId);
	}

	@Override
	public List<Product> getAllProduct() {
	
		return repo.getAllProduct();
	}

	@Override
	public List<Product> getByBrand(String prodBrand) {
		
		return repo.getByBrand(prodBrand);
	}

	@Override
	public List<Product> getByPriceRange(float min, float max) {

		return repo.getByPriceRange(min, max);
	}

	@Override
	public Product updateProduct(Product pro) {

		return repo.updateProduct(pro);
	}

	@Override
	public Product deleteProduct(int prodId) {
	
		return repo.deleteProduct(prodId);
	}

}
