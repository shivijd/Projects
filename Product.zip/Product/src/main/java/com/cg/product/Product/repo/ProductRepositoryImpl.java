package com.cg.product.Product.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.product.Product.bean.Product;

@Repository("repo")
public class ProductRepositoryImpl implements IProductRepository{

	@PersistenceContext
	EntityManager entityManager;
	
	


	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public Product addProduct(Product pro) {

		entityManager.persist(pro);
		entityManager.flush();
		return pro;
	}

	@Override
	public Product getById(int ProdId) {
		Product product= entityManager.find(Product.class, ProdId);
		if(product==null)
			return null;
		product.setProdid(ProdId);
		return product;
	}

	@Override
	public List<Product> getAllProduct() {
		
		TypedQuery<Product> query=entityManager.createQuery("select product  from  Product product ", Product.class);
			
		List<Product> list= query.getResultList();
	return list;
	}

	@Override
	public List<Product> getByBrand(String prodBrand) {
		Query query=(Query)entityManager.createQuery("Select product from Product product  where prodBrand=:prodBrand",Product.class).setParameter("prodBrand",prodBrand);
		List<Product> product=(List<Product>) query.getResultList();
	   return product;
		
	}

	@Override
	public List<Product> getByPriceRange(float min, float max) {
		TypedQuery<Product> query=(TypedQuery<Product>) entityManager.createQuery("Select product from Product product  where prodPrice BETWEEN :min and :max",Product.class);
		query.setParameter("min", min);
		query.setParameter("max", max);
		List<Product> product=(List<Product>) query.getResultList();
	   return product;
	}

	@Override
	public Product updateProduct(Product pro) {
	
	entityManager.merge(pro);
	entityManager.flush();
	return pro;
	}
	@Override
	public Product deleteProduct(int prodId) {
		Product product= entityManager.find(Product.class, prodId);
		entityManager.remove(product);
		entityManager.flush();
		return product;
	}
	
	
}
