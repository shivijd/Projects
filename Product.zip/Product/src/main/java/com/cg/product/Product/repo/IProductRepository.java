package com.cg.product.Product.repo;

import java.util.List;

import com.cg.product.Product.bean.Product;

public interface IProductRepository {
	
	public Product addProduct(Product pro);
	public Product getById(int ProdId);
	public List<Product> getAllProduct();
	public List<Product> getByBrand(String prodBrand);
	public List<Product> getByPriceRange(float min,float max);
	public Product updateProduct(Product pro);
	public Product deleteProduct(int prodId);

}
