package com.capgemini;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class UserSteps {
	
  private User user=new User();
/*  @Given("^that the user \"(.*)\" is to withdraw (\\d+)$")
  public void that_the_user_is_to_withdraw(String id,int balance) throws Throwable
  {
	  user.setid(id);
	  user.setBalance(balance);
	   throw new PendingException();
  }
  @When("^(\\d+)  is greater than  (\\d+)$")
  public void is_greater_than(int balance,int amount ) throws Throwable
  {
	  user.setBalance(balance);
	  user.setAmount(amount);
	  throw new PendingException();
  }
  @Then("^final(\\d+) after withdrawal$")
  public void final_after_withdrawal(String id,int amount)
  {
	  assertThat(id, is(user.getid()));
	  assertThat(user.withdrawBalance(id, amount),equalTo(user.getBalance()));
	  throw new PendingException();
	  
  }*/@Given("^that the user ABC is to withdraw  (\\d+)$")
  public void that_the_user_ABC_is_to_withdraw(int arg1) throws Throwable {
	
	  user.setBalance(arg1);
	  
	}

	@When("^(\\d+)  is greater than (\\d+)$")
	public void is_greater_than(int arg1, int arg2) throws Throwable {
	   
	}

	@Then("^final (\\d+) after withdrawal$")
	public void final_after_withdrawal(int arg1) throws Throwable {
	   
	}
}
