package com.capgemini;

public class User {
	private String id;
	
	private int balance;
	private int amount;
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getid() {
		return id;
	}
	public void setid(String id) {
		this.id = id;
	}
	
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
    public int withdrawBalance(String empid,int amount)
    {
    	if(this.balance>amount  && empid.equals(this.id))
    	{
    		balance=balance-amount;
    	}
    	
    	return balance;
    }
}
