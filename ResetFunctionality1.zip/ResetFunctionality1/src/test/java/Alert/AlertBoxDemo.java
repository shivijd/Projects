package Alert;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertBoxDemo
{
	public static void main(String args[]) throws InterruptedException
	{
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver","D:\\Users\\DLAVANIA\\Desktop\\Deeksha\\Module 3\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("D:\\Users\\DLAVANIA\\Desktop\\Deeksha\\Module 3\\hotelbooking.html");
		Thread.sleep(5000);
		Alert alert=driver.switchTo().alert();
		driver.findElement(By.id("alert")).click();
		System.out.println("The alert message is :"+ alert.getText());
		alert.accept();
		
		Thread.sleep(5000);
		
		driver.findElement(By.id("confirm")).click();
		Thread.sleep(5000);
		Alert confirm=driver.switchTo().alert();
		confirm.accept();
		Thread.sleep(5000);
		driver.findElement(By.id("confirm")).click();
		Thread.sleep(5000);
		confirm=driver.switchTo().alert();
		confirm.dismiss();
		Thread.sleep(5000);
		driver.findElement(By.id("prompt")).click();
		Thread.sleep(5000);
		Alert prompt=driver.switchTo().alert();
		
		String text=prompt.getText();
		System.out.println(text);
		prompt.sendKeys("Deeksha");
		Thread.sleep(5000);
		prompt.accept();
		Thread.sleep(5000);
		driver.findElement(By.id("prompt")).click();
		prompt=driver.switchTo().alert();
		prompt.dismiss();
		Thread.sleep(5000);
		driver.quit(); // to quit the browser
	}
	
}