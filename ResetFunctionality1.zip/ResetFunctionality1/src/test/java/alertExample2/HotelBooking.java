package alertExample2;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class HotelBooking {
	static WebDriver driver;
	public static void main(String[] args) throws InterruptedException
	{
		
		System.setProperty("webdriver.chrome.driver","D:\\Users\\DLAVANIA\\Desktop\\Deeksha\\Module 3\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("D:\\Users\\DLAVANIA\\Desktop\\Deeksha\\Module 3\\hotelbooking.html");
		
		/***********For Blank Name***************/
		driver.findElement(By.id("txtFirstName")).sendKeys("Deeksha");
		//driver.findElement(By.id("btnPayment")).click();
		//callAlert();
		
		driver.findElement(By.id("txtLastName")).sendKeys("Lavania");
		//driver.findElement(By.id("btnPayment")).click();
		//callAlert();

		driver.findElement(By.id("txtEmail")).sendKeys("dlavania00@gmail.com");
		//driver.findElement(By.id("btnPayment")).click();
		//callAlert();
		
		driver.findElement(By.cssSelector("input[pattern='[789][0-9]{9}']")).sendKeys("9897857709");


//		driver.findElement(By.cssSelector("input[pattern='[789][0-9]{9}']"))
		/*driver.findElement(By.id("txtPhone")).sendKeys("7894561230");
		driver.findElement(By.id("btnPayment")).click();*/
		
		driver.findElement(By.xpath("html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")).sendKeys("Pune");
		driver.findElement(By.id("btnPayment")).click();
		callAlert();
		
		Select dropCity=new Select(driver.findElement(By.name("city")));
		dropCity.selectByVisibleText("Pune");
		//driver.findElement(By.id("btnPayment")).click();
		//callAlert();
		

		Select dropCity1=new Select(driver.findElement(By.name("state")));
		dropCity1.selectByVisibleText("Tamilnadu");
		//driver.findElement(By.id("btnPayment")).click();
		//callAlert();
		
		Select dropCity2=new Select(driver.findElement(By.name("persons")));
		dropCity2.selectByVisibleText("2");
		//driver.findElement(By.id("btnPayment")).click();
		//callAlert();

		driver.findElement(By.id("txtCardholderName")).sendKeys("Deeksha");
		//driver.findElement(By.id("btnPayment")).click();
		//callAlert();
		
		driver.findElement(By.name("debit")).sendKeys("1234567890");
		//driver.findElement(By.id("btnPayment")).click();
		//callAlert();
		
		driver.findElement(By.id("txtCvv")).sendKeys("000");
		//driver.findElement(By.id("btnPayment")).click();
	    //callAlert();
		
		driver.findElement(By.id("txtMonth")).sendKeys("12");
		//driver.findElement(By.id("btnPayment")).click();
		//callAlert();
		
		driver.findElement(By.id("txtYear")).sendKeys("2022");
		driver.findElement(By.id("btnPayment")).click();
		//callAlert();
    




	}
		
		private static void callAlert()
		{
			String alertMessage=driver.switchTo().alert().getText();
			System.out.println(alertMessage);
			driver.switchTo().alert().accept();
		}
	

}
