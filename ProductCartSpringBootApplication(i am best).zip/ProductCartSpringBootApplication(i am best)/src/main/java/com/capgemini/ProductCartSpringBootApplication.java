package com.capgemini;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductCartSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductCartSpringBootApplication.class, args);
		
	}
	

}
