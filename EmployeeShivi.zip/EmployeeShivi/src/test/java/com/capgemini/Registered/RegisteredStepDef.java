package com.capgemini.Registered;

import static org.testng.Assert.assertEquals;

import com.capgemini.TestBase;
import com.capgemini.pages.LoginPage;
import com.capgemini.pages.Project;
import com.capgemini.pages.Resitered;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegisteredStepDef extends TestBase {
   static Project project;
   static LoginPage login;
   static Resitered regist;
	
	public RegisteredStepDef() {
	super();
	setup();
}

	private void setup() {
		initialization();
		project=new Project();
		login = new LoginPage();
	}

	@Given("^Project Page is open with successfully entering the details$")
	public void project_Page_is_open_with_successfully_entering_the_details() throws Throwable {
	    
	}

	@When("^Valid data entered in Project Page$")
	public void valid_data_entered_in_Project_Page() throws Throwable {
		project = login.pagelogin("1001", "abcd", "def", "pune");
		Thread.sleep(1000);
		regist = project.pageLogin("Shivi", "jv");
		Thread.sleep(30000);
	  
	}

	@Then("^Title of the page is (.*)$")
	public void title_of_the_page_is_Registered_successfully(String register) throws Throwable {
		assertEquals(register, regist.getHeading());
		Thread.sleep(3000);
		driver.quit();
	}


}
