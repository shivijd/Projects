package com.capgemini.ProjectTest;

import static org.testng.Assert.assertEquals;

import com.capgemini.TestBase;
import com.capgemini.pages.LoginPage;
import com.capgemini.pages.Project;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class ProjectTestStepDef extends TestBase {
	
	static LoginPage login;
	static Project project;
	
 public ProjectTestStepDef() {
		super();
		setup();
	}
	private void setup() {
	initialization();
	project=new Project();
	
}
	@Given("^Page is open to enter details$")
public void page_is_open_to_enter_details() throws Throwable {
    
}
	
	@When("^All data insert in login page is correct$")
	public void all_data_insert_in_login_page_is_correct() throws Throwable {
		  login=new LoginPage();
		  project=login.pagelogin("101", "shivi", "Pune", "UttarPradesh");
		  Thread.sleep(4000);
	   
	}

	@Then("^Check the title of the page as Page Title$")
	public void check_the_title_of_the_page() throws Throwable {
		project=new Project();
		assertEquals("Project page", project.getTitle1());
		Thread.sleep(4000);
		driver.quit();
	 
	}

	

}
