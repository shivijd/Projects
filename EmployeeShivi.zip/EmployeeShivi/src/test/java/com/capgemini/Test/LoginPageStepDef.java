package com.capgemini.Test;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.capgemini.TestBase;
import com.capgemini.pages.LoginPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class LoginPageStepDef extends TestBase {
	static LoginPage login;
	
	
	
	public LoginPageStepDef() {
		super();
		setup();
	}

	private void setup() {
	initialization();
 
		
	}

	@Given("^Login Page is opening$")
	public void login_Page_is_opening() throws Throwable {
	   
	  
	}

	@When("^Login Page is open$")
	public void login_Page_is_open() throws Throwable {
	 
	}

	@Then("^Title of page is (.*)$")
	public void title_of_page_is_project(String Login) throws Throwable {
		login=new LoginPage();
		assertEquals(Login, login.getTitle());
		driver.quit();
	   
	}
	
	@When("^User leave name as blank$")
	public void user_leave_name_as_blank() throws Throwable {
		login=new LoginPage();
		login.pagelogin("101", "", "pune", "Maha");
		Thread.sleep(3000);
	   
	}

	@Then("^Alert message to be displayed$")
	public void alert_message_to_be_displayed() throws Throwable {
		
	Alert alert=driver.switchTo().alert();
	assertEquals("Please enter Employee id", alert.getText());
	driver.quit();

	}



}
