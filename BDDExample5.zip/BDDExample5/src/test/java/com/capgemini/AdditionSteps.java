package com.capgemini;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AdditionSteps {
	Addition add=new Addition();
	@Given("^that number1 is(\\d+) and number2 is(\\d+)$")
	public void setInformation(int number1,int number2)
	{
		add.setNum1(number1);
		add.setNum2(number2);
	}
	@When("^(\\d+) and (\\d+) are greater than zero$ ")
	public void readyForAddition(int number1,int number2)
	{
		add.setNum1(number1);
		add.setNum2(number2);
	}
	@Then("^addition of numbers is (\\d+)")
	public void additionOfNumbers(int number1,int number2)
	{
		assertThat(number1, is(add.getNum1()));
		assertThat(number2, is(add.getNum2()));
		assertThat(add.getResult(number1, number2), equalTo(add.getNum3()));
	}

}
