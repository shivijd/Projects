package com.capg;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Seleni {
	WebDriver driver;


	  public static void main(String[] args) throws InterruptedException {
		new Seleni().tripDetails();
	}
	  public void tripDetails() throws InterruptedException
	  {

		  System.setProperty("webdriver.chrome.driver","C:\\Users\\SHJADAUN\\Downloads\\chromedriver_win32\\chromedriver.exe");
		   driver=new ChromeDriver();
		   driver.manage().deleteAllCookies();
			driver.manage().window().maximize();
			 driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
			  Thread.sleep(100);
		          driver.get("https://www.amazon.in");
		          driver.findElement(By.cssSelector("input[id='twotabsearchtextbox']")).sendKeys("soap");
		          driver.findElement(By.cssSelector("input[id='twotabsearchtextbox']")).sendKeys(Keys.ENTER);
		          driver.findElement(By.linkText("https://www.amazon.in/Park-Avenue-Soap-Luxury-125g/dp/B077GZ5D23/ref=sr_1_5?keywords=soap&qid=1552973176&s=gateway&sr=8-5")).click();
		          Set<String> ids = driver.getWindowHandles();
		          Iterator<String> it = ids.iterator();
		          String parentId = it.next();
		          String childId = it.next();
		          driver.switchTo().window(childId);
		          driver.findElement(By.id("add-to-cart-button")).click();
		      }

		  
		}
	
	
		
		  
