package com.capgemini.crud.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capgemini.crud.Employee;
import com.capgemini.crud.repository.Repository;


@Service
public class ServiceClass {
	@Autowired
	private Repository repo;
	  public ServiceClass(Repository repo) {
		     repo.save(new Employee("101", "Shivi", "Devloper", 20000));
			 repo.save(new Employee("102", "Shikha", "Monitor", 10000));
			 repo.save(new Employee("103", "Sarita", "Devops", 3000));
	}

	public List<Employee> getAllEmployee(){  
		  List<Employee>user = new ArrayList<>(); 
	      repo.findAll().forEach(user::add); 
	        return user;  
	    }  
	 
		public Optional<Employee> getEmployee(String empId){  
	        return repo.findById(empId); 
	    }  
	    public void addEmployee(Employee employee){  
	        repo.save(employee);
	    }  
	    public void delete(String empId){  
	        repo.deleteById(empId);
	    }  

}
