package com.capgemini.crud.repository;

import org.springframework.data.repository.CrudRepository;

import com.capgemini.crud.Employee;

public interface Repository extends CrudRepository<Employee,String> {
	
}
