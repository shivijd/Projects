package com.capgemini.crud.controller;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.crud.Employee;
import com.capgemini.crud.service.ServiceClass;

@RestController
public class Controller {
@Autowired
private ServiceClass service;
@RequestMapping("/")  
public List<Employee> getAllEmployee(){  
    return service.getAllEmployee(); 
}     
@RequestMapping(value="/add-employee", method=RequestMethod.POST)  
public void addEmployee(@RequestBody Employee employee){  
    service.addEmployee(employee);
}  
@RequestMapping(value="/employee/{empId}", method=RequestMethod.GET)  
public Optional<Employee> getUser(@PathVariable String empId){  
    return service.getEmployee(empId); 
}  
}  

