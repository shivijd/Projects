package PageBeanProject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class ProjectBean {

	WebDriver driver;
	
	@FindBy(name="fn")
	@CacheLookup
	WebElement pffname;

	public WebElement getPfname() {
		return pffname;
	}

	public void setPffname(String sfname) {
		pffname.sendKeys(sfname);
	}
	
	
}
